ZERO // COUNTDOWN

Открой index.html для локального просмотра.
Для публикации: создай GitHub repository, загрузи index.html и включи Settings -> Pages -> Deploy from branch -> main -> /(root).
